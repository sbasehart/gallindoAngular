var mongoose = require('mongoose');

var CategorySchema = new mongoose.Schema({
  id: String,
  catName: String,
  catFirst: String,
  catSecond: String,
  catThird: String,
  updated: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Category', CategorySchema);