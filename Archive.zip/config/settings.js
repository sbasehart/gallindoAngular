module.exports = {
    'secret':'meansecure'
};